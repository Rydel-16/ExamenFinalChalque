from django.db import models

# Create your models here.
class Articulo(models.Model):
    codigo = models.TextField()
    nombre = models.TextField()
    horas = models.TextField()
    creditos = models.TextField()
    estado = models.TextField()
