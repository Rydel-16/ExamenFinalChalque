from django.shortcuts import render, HttpResponse, redirect
from miapp.models import Articulo
from django.db.models import Q

# Create your views here.

layout = """

"""

def index(request):
    return render(request,'index.html',{
        'titulo': 'Inicio',
    })

def listar_articulos(request):
    articulos = Articulo.objects.all()    
    return render(request,'listar_articulos.html',{
        'articulos': articulos,
        'titulo': 'Listado de Cursos'
    })

def eliminar_articulo(request, id):
    articulo = Articulo.objects.get(pk=id)
    articulo.delete()
    return redirect('listar_articulos')

def listar_carreras(request):   
    return render(request,'listar_carreras.html',{
        'titulo': 'Listado de Carreras'
    })
def listar_Estudiantes(request):   
    return render(request,'listar_estudiantes.html',{
        'titulo': 'Listado de Estudiantes'
    })
def Consultas(request):   
    return render(request,'consultas.html',{
        'titulo': 'Consultas y comentarios'
    })
    
